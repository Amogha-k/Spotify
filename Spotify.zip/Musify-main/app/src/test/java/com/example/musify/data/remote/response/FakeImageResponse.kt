package com.example.musify.data.remote.response

val fakeImageResponse = ImageResponse(
    height = 10,
    width = 10,
    "testUrl"
)