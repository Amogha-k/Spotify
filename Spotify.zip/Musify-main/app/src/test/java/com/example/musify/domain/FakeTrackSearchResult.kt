package com.example.musify.domain

val fakeTrackSearchResult = SearchResult.TrackSearchResult(
    "testId",
    "Test Track",
    "",
    "Artist1,Artist2",
    ""
)