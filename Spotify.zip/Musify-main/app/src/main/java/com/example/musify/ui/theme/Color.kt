package com.example.musify.ui.theme

import androidx.compose.ui.graphics.Color

val spotifyGreen = Color(0xFF1DB954)