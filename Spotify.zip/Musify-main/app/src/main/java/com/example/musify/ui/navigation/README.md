# Navigation graph
![Image of the navigation graph](https://github.com/t3chkid/Musify/blob/main/screenshots/navigation-illustration.png)
